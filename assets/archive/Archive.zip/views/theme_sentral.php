<?php if ( function_exists( 'date_default_timezone_set' ) )
date_default_timezone_set('Asia/Jakarta'); ?>
<?php $this->load->view('theme_head'); ?>
<?php $this->load->view('theme_section'); ?>
<?php $this->load->view('theme_footer'); ?>